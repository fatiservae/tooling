void DestroyFileMap(DviFileMap *);
void FileSeek(DviWidget, long);
void ForgetPagePositions(DviWidget);
void RememberPagePosition(DviWidget, int);
long SearchPagePosition(DviWidget, int);
