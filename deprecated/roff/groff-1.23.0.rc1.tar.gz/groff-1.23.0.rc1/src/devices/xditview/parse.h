int ParseInput(register DviWidget dw);
