void DestroyFontMap(DviFontMap *);
void ForgetFonts (DviWidget dw);
int MaxFontPosition (DviWidget dw);
void ParseFontMap (DviWidget dw);
void SetFontPosition (DviWidget dw, int position, const char *dvi_name,
                      const char *extra);
